#include <iostream>
#include <fstream>
#include <src/XmlParser.cpp>
#include <src/XmlElement.cpp>

int main(const int argc, const char** argv)
{
    //File handling
    std::string fileName = "cfg/parameters.xml";
    XmlParser myParser(fileName);
    // int runTimeSettings = myParser.getElement("runTimeSettings").toString();
    
    std::cout << "runTimeSettings: " << myParser.getElement("Option2/runTimeSettings").toString() << std::endl; 

    std::cout << "manifest settings: " << myParser.getElement("SubOption1/SubSubOption1/manifestSettings").toInt() << std::endl;

    std::vector<XmlElement> list = myParser.getElementList("attributeType");
    for (int i = 0; i < list.size(); i++)
    {
        std::cout << "attributeType: " << list[i].toInt() << std::endl;
    }

    return 0;
}