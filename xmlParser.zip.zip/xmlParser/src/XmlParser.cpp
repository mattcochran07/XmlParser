#include <XmlParser.h>

#include <sstream>
#include <fstream>
#include <iostream>

XmlParser::XmlParser()
{

}

XmlParser::XmlParser(std::string fileName)
{
    _fileName = fileName;
}

XmlParser::~XmlParser()
{

}

void XmlParser::printFileContents()
{
    std::cout << "File Contents:\n" << _fileContents << std::endl;
}

std::string XmlParser::getComplexElementString(const std::string elementName)
{
    std::string editElementName = elementName;
    std::string editFileContents = _fileContents;
    unsigned startPos, endPos = 0;
    while (editElementName.find("/") != std::string::npos)
    {
        std::string outerName = "";
        unsigned pos = editElementName.find("/");
        unsigned itr = 0;
        while (itr < pos)
        {
            outerName += editElementName.at(itr++);
        }
        startPos = editFileContents.find("<" + outerName + ">");
        endPos = editFileContents.find("</" + outerName + ">");
        editFileContents.erase(0, startPos);
        // editFileContents.erase(endPos, editFileContents.size()-1);
        editElementName.erase(0, ++pos);
    }
    std::string elementStr = "";
    //now all thats left is the element name, no more '/'
    startPos = editFileContents.find("<" + editElementName + ">") + editElementName.size() + 2;
    endPos = editFileContents.find("</" + editElementName + ">");
    for (unsigned i = startPos; i < endPos; i++)
    {
        elementStr += editFileContents.at(i);
    }
    return elementStr;
}

XmlElement XmlParser::getElement(const std::string elementName)
{
    XmlElement element;
    if (_fileContents == "")
    {
        std::ifstream ifs(_fileName);
        std::string fileContents = "";
        if (ifs.is_open())
        {
            std::string data((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
            fileContents = data;
            ifs.close();
        }
        _fileContents = fileContents;
        removeComments();
    }
    if ((_fileContents.find("<" + elementName + ">") != std::string::npos) && 
        (_fileContents.find("</" + elementName + ">") != std::string::npos)) //successfully found element
    {
        unsigned startPos = _fileContents.find("<" + elementName + ">") + elementName.size() + 2;
        unsigned endPos = _fileContents.find("</" + elementName + ">");
        std::string elementStr = "";
        unsigned counterPos = startPos;
        while (counterPos < endPos)
        {
            elementStr += _fileContents.at(counterPos);
            counterPos++;
        }
        element.setElementString(elementStr);
    }
    else if (elementName.find("/") != std::string::npos)
    {
        std::string elementStr = getComplexElementString(elementName);
        element.setElementString(elementStr);
    }
    return element;
}

std::vector<XmlElement> XmlParser::getElementList(const std::string elementName)
{
    std::vector<XmlElement> myList;

    if (_fileContents == "")
    {
        std::ifstream ifs("_fileName");
        if (ifs.is_open())
        {
            std::string data((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
            _fileContents = data;
            ifs.close();
        }
        removeComments();
    }
    std::string editFileContents = _fileContents;
    while ((editFileContents.find("<" + elementName + ">") != std::string::npos) &&
           (editFileContents.find("</" + elementName + ">") != std::string::npos))
    {
        unsigned startPos = editFileContents.find("<" + elementName + ">") + elementName.size() + 2;
        unsigned endPos = editFileContents.find("</" + elementName + ">");
        if (elementName.find("/") != std::string::npos)
        {
            startPos = 1;
            endPos = 2;
        }
        std::string elementStr = "";
        unsigned itr = startPos;
        while (itr < endPos)
        {
            elementStr += editFileContents.at(itr++);
        }
        XmlElement element;
        element.setElementString(elementStr);
        myList.push_back(element);
        //remove element from editFileContents
        editFileContents.erase(0, endPos + elementName.size() + 3);
    }

    return myList;
}

void XmlParser::removeComments()
{
    while ((_fileContents.find("<!--") != std::string::npos) && 
           (_fileContents.find("-->") != std::string::npos))
    {
        unsigned startPos = _fileContents.find("<!--");
        unsigned endPos = _fileContents.find("-->") + 3;
        _fileContents.erase(startPos, endPos);
    }
}