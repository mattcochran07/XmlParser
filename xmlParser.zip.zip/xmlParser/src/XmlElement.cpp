#include <XmlElement.h>

#include <iostream>

XmlElement::XmlElement()
{
    _elementString = "";
}

XmlElement::~XmlElement()
{

}

std::string XmlElement::toString()
{
    return _elementString;
}

int XmlElement::toInt()
{
    std::stringstream ss;
    ss << _elementString;
    int element;
    ss >> element;
    return element;
}

float XmlElement::toFloat()
{
    std::stringstream ss;
    ss << _elementString;
    float element;
    ss >> element;
    return element;
}

double XmlElement::toDouble()
{
    std::stringstream ss;
    ss << _elementString;
    double element;
    ss >> element;
    return element;
}

long XmlElement::toLong()
{
    std::stringstream ss;
    ss << _elementString;
    long element;
    ss >> element;
    return element;
}

bool XmlElement::toBool()
{
    std::stringstream ss;
    ss << _elementString;
    bool element;
    ss >> element;
    return element;
}

std::stringstream XmlElement::toStringstream()
{
    std::stringstream ss;
    ss << _elementString;
    return ss;
}