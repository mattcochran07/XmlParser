#ifndef XML_PARSER_H__
#define XML_PARSER_H__

#include <string>
#include <XmlElement.h>
#include <vector>

class XmlParser 
{
public:
    XmlParser();
    XmlParser(std::string fileName);
    virtual ~XmlParser();
    void setFileName(std::string fileName) {_fileName = fileName;}
    XmlElement getElement(const std::string elementName);
    std::vector<XmlElement> getElementList(const std::string elementName);

private:
    void removeComments();
    void printFileContents();
    std::string getComplexElementString(const std::string elementName);
    std::string _fileName;
    std::string _fileContents;
};

#endif //XML_PARSER_H__