#ifndef XML_ELEMENT_H__
#define XML_ELEMENT_H__

#include <string>
#include <sstream>

class XmlElement
{
public:
    XmlElement();
    ~XmlElement();
    void setElementString(std::string str) {_elementString = str;}
    
    //return methods
    std::string toString();
    int toInt();
    float toFloat();
    double toDouble();
    long toLong();
    bool toBool();
    std::stringstream toStringstream();

private:
    std::string _elementString;
};

#endif